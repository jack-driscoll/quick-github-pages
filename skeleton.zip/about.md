---
layout: page
title: "About Me"
date: 2025-06-02
permalink: /about/
categories: [personal, page]
tags: [description, tags, not-necessary]
author: jackd
description: "An About Me page for Jack Driscoll"
---

# PUT YOUR NAME HERE

This is another page, an about page available at 
http://yourname.github.io/about/

## THIS IS A SUBSECTION

*this is in italics*

**this is bold**

[here's a link to https://jack.ethertech.org/](https://jack.ethertech.org/)

## What if I want more?

Here's a [cheatsheet](https://www.markdownguide.org/cheat-sheet/)

Here's a [complete markdown guide](https://www.markdownguide.org/basic-syntax/)

### Jack Driscoll (jackd/Jack'D)

If you'd like to know more about [me](https://jackd.ethertech.org/), 

you can send me electronic mail at 
[GMail](jack.driscoll@gmail.com) or [EtherTech](root@ethertech.org).

PLEASE DO NOT ASK ME QUESTIONS ABOUT THIS GUIDE.
IT IS AS SIMPLE OR AS COMPLICATED AS YOU WANT TO MAKE IT.  THIS IS SIMPLE.