---
layout: post
title: "MOAR FEATURES!"
date: 2023-11-11 20:04:15 -0000
categories: mindless-content unnecessary-post
# ignore /YYYY/MM/DD/title.html
permalink: /FEATURES.html
tags: fishsticks shite
---

# Put the mindless content here
## Whhyy?
Realistically, I'm never going to use all these features 
