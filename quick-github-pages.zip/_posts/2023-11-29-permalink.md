---
layout: post
title: "MOAR FEATURES!"
date: 2023-11-11 20:04:15 -0000
categories: mindless-content unnecessary-post
# ignore /YYYY/MM/DD/title.html
permalink: /FEATURES.html
tags: fishsticks shite
---

# Put the mindless content here

## Whhyy?

Realistically, I'm never going to use all these features 

### What is this?

This `post` has a **permalink**, so instead of the relatively crappy URL
of https://yourname.github.io//mindless-content/unnecessary-post/2023/11/29/permalink.html
it is https://yourname.github.io/FEATURES.html even though it's a `post`

### What's with the date vs filename date?

:wq

Also note, the date can be different than the filename, the date from the
`frontmatter` at the top is used for the file.