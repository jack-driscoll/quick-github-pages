---
layout: page
title: "A page"
permalink: /page.html
---

This is honestly all you really need to make a page titled "A page".

This will be available at yourname.github.io/page.html

Add to it in markdown format.  The only thing that makes it a page is that it's
set to "layout:page" in that thingy at the top ("the frontmatter")