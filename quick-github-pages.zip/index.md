---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: home
---

# What is this?

This is the easiest way to get started on GitHub Pages.  Modify these files,
put them a repo called yourname.github.io (see README).  You're online!

## What do I do

This is your homepage, all you have to do is read the README and add your
"main page" contents here!

## HI THERE I'M ME

[Contact me](mailto:youremail@provider.com)  I'm telling you all about myself
because I want to share things about me online.  Isn't the internet great?

It certainly could be, but it's so complex, isn't it!?  ***NOT ANYMORE***

Now, it's ***EASY AS SHITTING***!!!

